"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Package, PackagePlus, PackageMinus, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react"

const stats = [
  { label: "Tồn kho", value: "8,456", change: "+5%", trend: "up", icon: Package, color: "bg-primary/10 text-primary" },
  { label: "Nhập hôm nay", value: "156", change: "+12%", trend: "up", icon: PackagePlus, color: "bg-success/10 text-success" },
  { label: "Xuất hôm nay", value: "89", change: "-3%", trend: "down", icon: PackageMinus, color: "bg-chart-3/10 text-chart-3" },
  { label: "Sắp hết hạn", value: "18", change: "+3", trend: "up", icon: AlertTriangle, color: "bg-destructive/10 text-destructive" },
]

export function StatsCards() {
  return (
    <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.label} className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
                <div className="flex items-center gap-1 mt-1">
                  {stat.trend === "up" ? <TrendingUp className="h-3 w-3 text-success" /> : <TrendingDown className="h-3 w-3 text-destructive" />}
                  <span className={`text-xs ${stat.trend === "up" ? "text-success" : "text-destructive"}`}>{stat.change}</span>
                </div>
              </div>
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${stat.color}`}>
                <stat.icon className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
