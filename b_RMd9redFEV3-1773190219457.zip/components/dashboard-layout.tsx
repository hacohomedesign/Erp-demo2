"use client"

import { Sidebar } from "@/components/sidebar"

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-[100dvh] bg-background">
      <Sidebar />
      <main className="pt-14 lg:pl-52 lg:pt-0">
        <div className="p-3 lg:p-4 pb-20 lg:pb-6">
          {children}
        </div>
      </main>
    </div>
  )
}
