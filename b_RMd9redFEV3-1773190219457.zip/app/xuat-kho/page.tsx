"use client"

import { useState, useRef } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useVoiceInput } from "@/hooks/use-voice-input"
import { Mic, MicOff, QrCode, Search, Minus, Plus, X, Loader2, PackageMinus } from "lucide-react"

interface InventoryItem {
  id: number
  name: string
  sku: string
  stock: number
  unit: string
}

interface CartItem extends InventoryItem {
  qty: number
}

const inventory: InventoryItem[] = [
  { id: 1, name: "Mì Hảo Hảo tôm chua cay", sku: "HH-TCH-30", stock: 150, unit: "thùng" },
  { id: 2, name: "Nước suối Lavie 500ml", sku: "LV-500-24", stock: 200, unit: "thùng" },
  { id: 3, name: "Dầu ăn Neptune 1L", sku: "NP-1L-12", stock: 80, unit: "thùng" },
  { id: 4, name: "Nước mắm Chinsu 500ml", sku: "CS-500-24", stock: 120, unit: "thùng" },
  { id: 5, name: "Sữa đặc Ông Thọ", sku: "OT-380-48", stock: 90, unit: "thùng" },
  { id: 6, name: "Bánh Oreo 150g", sku: "OR-150-24", stock: 60, unit: "thùng" },
]

const customers = [
  "UBND Quận 1", "UBND Quận 3", "Hội Chữ Thập Đỏ", "Trường THPT Lê Quý Đôn", 
  "Bệnh viện Quận 3", "Công ty ABC", "NGO Việt Nam"
]

export default function StockOutPage() {
  const { isListening, transcript, startListening, stopListening, resetTranscript, isSupported } = useVoiceInput()
  const [search, setSearch] = useState("")
  const [cart, setCart] = useState<CartItem[]>([])
  const [customer, setCustomer] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [showScanner, setShowScanner] = useState(false)

  const filtered = inventory.filter(
    (item) => item.name.toLowerCase().includes(search.toLowerCase()) || item.sku.toLowerCase().includes(search.toLowerCase())
  )

  const addToCart = (item: InventoryItem) => {
    const existing = cart.find((c) => c.id === item.id)
    if (existing) {
      if (existing.qty < item.stock) {
        setCart(cart.map((c) => (c.id === item.id ? { ...c, qty: c.qty + 1 } : c)))
      }
    } else {
      setCart([...cart, { ...item, qty: 1 }])
    }
  }

  const updateQty = (id: number, delta: number) => {
    setCart(
      cart.map((item) => {
        const newQty = item.qty + delta
        if (newQty <= 0) return null
        if (newQty > item.stock) return item
        return { ...item, qty: newQty }
      }).filter(Boolean) as CartItem[]
    )
  }

  const removeItem = (id: number) => setCart(cart.filter((item) => item.id !== id))

  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0)

  const handleSubmit = async () => {
    if (cart.length === 0 || !customer) return
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSubmitting(false)
    setShowSuccess(true)
    setTimeout(() => {
      setCart([])
      setCustomer("")
      setShowSuccess(false)
    }, 2000)
  }

  const parseVoiceCommand = () => {
    if (!transcript) return
    const text = transcript.toLowerCase()
    // Extract customer name
    const customerMatch = customers.find(c => text.includes(c.toLowerCase()))
    if (customerMatch) setCustomer(customerMatch)
    // Extract product
    const productMatch = inventory.find(p => text.includes(p.name.toLowerCase()))
    if (productMatch) addToCart(productMatch)
  }

  const startScanner = () => {
    setShowScanner(true)
    setTimeout(() => {
      const product = inventory[Math.floor(Math.random() * inventory.length)]
      addToCart(product)
      setShowScanner(false)
    }, 1500)
  }

  return (
    <DashboardLayout>
      <div className="mb-4">
        <h1 className="text-xl font-bold">Xuất kho</h1>
        <p className="text-sm text-muted-foreground">Xuất hàng cho cơ quan, tổ chức, NGO</p>
      </div>

      {/* Success */}
      {showSuccess && (
        <div className="mb-4 p-4 rounded-lg bg-success/10 text-success text-sm font-medium">
          Xuất kho thành công! Phiếu xuất đã được tạo.
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <Button
          onClick={isListening ? stopListening : startListening}
          disabled={!isSupported}
          className={`h-16 flex-col gap-1 ${isListening ? "bg-destructive hover:bg-destructive/90" : ""}`}
        >
          {isListening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
          <span className="text-xs">{isListening ? "Dừng" : "Giọng nói"}</span>
        </Button>
        <Button onClick={showScanner ? () => setShowScanner(false) : startScanner} variant={showScanner ? "destructive" : "default"} className="h-16 flex-col gap-1">
          <QrCode className="h-5 w-5" />
          <span className="text-xs">{showScanner ? "Dừng" : "Scan mã"}</span>
        </Button>
      </div>

      {/* Voice Transcript */}
      {transcript && (
        <Card className="border-0 shadow-sm mb-4">
          <CardContent className="p-3">
            <p className="text-sm mb-2">{transcript}</p>
            <div className="flex gap-2">
              <Button onClick={parseVoiceCommand} size="sm" className="flex-1 h-9">Áp dụng</Button>
              <Button onClick={resetTranscript} variant="outline" size="sm" className="h-9 px-3"><X className="h-4 w-4" /></Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Scanner */}
      {showScanner && (
        <Card className="border-0 shadow-sm mb-4">
          <CardContent className="p-4">
            <div className="h-32 bg-muted rounded-lg flex items-center justify-center">
              <QrCode className="h-10 w-10 text-muted-foreground animate-pulse" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Tìm sản phẩm..."
          className="h-12 pl-10"
        />
      </div>

      {/* Products */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        {filtered.slice(0, 6).map((item) => {
          const inCart = cart.find((c) => c.id === item.id)
          return (
            <button
              key={item.id}
              onClick={() => addToCart(item)}
              className="p-3 rounded-lg border bg-card text-left hover:border-primary transition-colors"
            >
              <p className="font-medium text-sm truncate">{item.name}</p>
              <p className="text-xs text-muted-foreground">{item.sku}</p>
              <div className="flex items-center justify-between mt-2">
                <span className="text-sm font-semibold text-primary">{item.stock}</span>
                {inCart && <span className="text-xs bg-success text-success-foreground px-2 py-0.5 rounded-full">+{inCart.qty}</span>}
              </div>
            </button>
          )
        })}
      </div>

      {/* Cart */}
      <Card className="border-0 shadow-sm mb-4">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-sm">Giỏ xuất</h2>
            <span className="text-xs bg-chart-3/10 text-chart-3 px-2 py-1 rounded-full font-medium">{totalItems} sản phẩm</span>
          </div>
          {cart.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">Chưa có sản phẩm</p>
          ) : (
            <div className="space-y-2">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center gap-2 p-2 rounded-lg bg-muted/50">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{item.name}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQty(item.id, -1)}>
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="w-8 text-center text-sm font-semibold">{item.qty}</span>
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQty(item.id, 1)} disabled={item.qty >= item.stock}>
                      <Plus className="h-3 w-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeItem(item.id)}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Customer */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4 space-y-3">
          <select
            value={customer}
            onChange={(e) => setCustomer(e.target.value)}
            className="w-full h-12 px-3 rounded-lg border bg-background text-sm"
          >
            <option value="">Chọn khách hàng</option>
            {customers.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <Button onClick={handleSubmit} disabled={cart.length === 0 || !customer || isSubmitting} className="w-full h-12">
            {isSubmitting ? <Loader2 className="h-5 w-5 animate-spin" /> : <><PackageMinus className="h-5 w-5 mr-2" />Tạo phiếu xuất</>}
          </Button>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
