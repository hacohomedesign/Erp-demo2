"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Package, PackagePlus, PackageMinus, TrendingUp, Download, ArrowUpRight, ArrowDownRight } from "lucide-react"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"

const monthlyData = [
  { name: "T1", nhap: 800, xuat: 600 },
  { name: "T2", nhap: 1000, xuat: 750 },
  { name: "T3", nhap: 1200, xuat: 900 },
  { name: "T4", nhap: 1100, xuat: 850 },
  { name: "T5", nhap: 1400, xuat: 1100 },
  { name: "T6", nhap: 1300, xuat: 1000 },
]

const weeklyData = [
  { name: "T2", tuanNay: 120, tuanTruoc: 100 },
  { name: "T3", tuanNay: 150, tuanTruoc: 130 },
  { name: "T4", tuanNay: 180, tuanTruoc: 140 },
  { name: "T5", tuanNay: 200, tuanTruoc: 160 },
  { name: "T6", tuanNay: 170, tuanTruoc: 150 },
  { name: "T7", tuanNay: 90, tuanTruoc: 80 },
  { name: "CN", tuanNay: 60, tuanTruoc: 50 },
]

const topProducts = [
  { name: "Mì Hảo Hảo", sold: 450, revenue: "135tr" },
  { name: "Nước suối Lavie", sold: 380, revenue: "95tr" },
  { name: "Dầu Neptune", sold: 220, revenue: "176tr" },
  { name: "Sữa Vinamilk", sold: 310, revenue: "155tr" },
  { name: "Nước mắm Chinsu", sold: 180, revenue: "54tr" },
]

const topCustomers = [
  { name: "UBND Quận 1", orders: 12, total: "280tr" },
  { name: "Hội Chữ Thập Đỏ", orders: 8, total: "195tr" },
  { name: "Bệnh viện Quận 3", orders: 15, total: "320tr" },
  { name: "Trường THPT LQĐ", orders: 6, total: "145tr" },
]

export default function ReportsPage() {
  const [range, setRange] = useState<"week" | "month">("month")

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-xl font-bold">Báo cáo</h1>
          <p className="text-sm text-muted-foreground">Thống kê kho hàng</p>
        </div>
        <Button variant="outline" size="sm" className="h-9">
          <Download className="h-4 w-4 mr-2" />Xuất
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Tổng giá trị kho</p>
                <p className="text-xl font-bold">2.8 tỷ</p>
                <div className="flex items-center gap-1 text-xs text-success">
                  <ArrowUpRight className="h-3 w-3" />+8%
                </div>
              </div>
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Package className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Doanh số tháng</p>
                <p className="text-xl font-bold">615tr</p>
                <div className="flex items-center gap-1 text-xs text-success">
                  <ArrowUpRight className="h-3 w-3" />+12%
                </div>
              </div>
              <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Nhập tháng</p>
                <p className="text-xl font-bold">1,400</p>
                <div className="flex items-center gap-1 text-xs text-success">
                  <ArrowUpRight className="h-3 w-3" />+5%
                </div>
              </div>
              <div className="h-10 w-10 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <PackagePlus className="h-5 w-5 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Xuất tháng</p>
                <p className="text-xl font-bold">1,100</p>
                <div className="flex items-center gap-1 text-xs text-destructive">
                  <ArrowDownRight className="h-3 w-3" />-3%
                </div>
              </div>
              <div className="h-10 w-10 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <PackageMinus className="h-5 w-5 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Range Toggle */}
      <div className="flex gap-2 mb-4">
        <Button variant={range === "week" ? "default" : "outline"} size="sm" onClick={() => setRange("week")} className="h-9">Tuần</Button>
        <Button variant={range === "month" ? "default" : "outline"} size="sm" onClick={() => setRange("month")} className="h-9">Tháng</Button>
      </div>

      {/* Chart */}
      <Card className="border-0 shadow-sm mb-4">
        <CardContent className="p-4">
          <h2 className="font-semibold text-sm mb-4">Biến động kho</h2>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              {range === "month" ? (
                <AreaChart data={monthlyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorNhap" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.6 0.18 145)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.6 0.18 145)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorXuat" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.75 0.18 75)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.75 0.18 75)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0 0)" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: "oklch(0.45 0 0)", fontSize: 11 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "oklch(0.45 0 0)", fontSize: 11 }} />
                  <Tooltip contentStyle={{ backgroundColor: "oklch(1 0 0)", border: "1px solid oklch(0.92 0 0)", borderRadius: "8px" }} />
                  <Area type="monotone" dataKey="nhap" stroke="oklch(0.6 0.18 145)" strokeWidth={2} fillOpacity={1} fill="url(#colorNhap)" name="Nhập" />
                  <Area type="monotone" dataKey="xuat" stroke="oklch(0.75 0.18 75)" strokeWidth={2} fillOpacity={1} fill="url(#colorXuat)" name="Xuất" />
                </AreaChart>
              ) : (
                <BarChart data={weeklyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0 0)" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: "oklch(0.45 0 0)", fontSize: 11 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "oklch(0.45 0 0)", fontSize: 11 }} />
                  <Tooltip contentStyle={{ backgroundColor: "oklch(1 0 0)", border: "1px solid oklch(0.92 0 0)", borderRadius: "8px" }} />
                  <Bar dataKey="tuanTruoc" fill="oklch(0.92 0 0)" radius={[4, 4, 0, 0]} name="Tuần trước" />
                  <Bar dataKey="tuanNay" fill="oklch(0.55 0.2 250)" radius={[4, 4, 0, 0]} name="Tuần này" />
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-center gap-4 mt-3">
            {range === "month" ? (
              <>
                <div className="flex items-center gap-2"><div className="h-2 w-2 rounded-full bg-success" /><span className="text-xs text-muted-foreground">Nhập</span></div>
                <div className="flex items-center gap-2"><div className="h-2 w-2 rounded-full bg-chart-3" /><span className="text-xs text-muted-foreground">Xuất</span></div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2"><div className="h-2 w-2 rounded-full bg-muted" /><span className="text-xs text-muted-foreground">Tuần trước</span></div>
                <div className="flex items-center gap-2"><div className="h-2 w-2 rounded-full bg-primary" /><span className="text-xs text-muted-foreground">Tuần này</span></div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Top Products */}
      <Card className="border-0 shadow-sm mb-4">
        <CardContent className="p-4">
          <h2 className="font-semibold text-sm mb-3">Top sản phẩm bán chạy</h2>
          <div className="space-y-2">
            {topProducts.map((p, i) => (
              <div key={p.name} className="flex items-center gap-3">
                <span className={`h-7 w-7 rounded-lg flex items-center justify-center text-xs font-bold ${i === 0 ? "bg-warning text-warning-foreground" : i === 1 ? "bg-muted text-muted-foreground" : i === 2 ? "bg-chart-3/20 text-chart-3" : "bg-muted/50 text-muted-foreground"}`}>{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.sold} đã bán</p>
                </div>
                <span className="text-sm font-semibold text-primary">{p.revenue}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Customers */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <h2 className="font-semibold text-sm mb-3">Khách hàng lớn</h2>
          <div className="space-y-2">
            {topCustomers.map((c) => (
              <div key={c.name} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{c.orders} đơn hàng</p>
                </div>
                <span className="text-sm font-semibold">{c.total}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
