"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Truck, MapPin, Phone, CheckCircle2, Circle, Navigation } from "lucide-react"

type Status = "pending" | "shipping" | "done"

interface Task {
  id: number
  code: string
  customer: string
  phone: string
  address: string
  items: number
  status: Status
  time: string
  urgent: boolean
}

const initialTasks: Task[] = [
  { id: 1, code: "DH001", customer: "UBND Quận 1", phone: "0901234567", address: "123 Nguyễn Huệ, Q1", items: 25, status: "pending", time: "9:00-10:00", urgent: true },
  { id: 2, code: "DH002", customer: "Hội Chữ Thập Đỏ", phone: "0912345678", address: "456 Lê Văn Sỹ, Q3", items: 50, status: "shipping", time: "10:00-11:00", urgent: false },
  { id: 3, code: "DH003", customer: "Trường THPT Lê Quý Đôn", phone: "0923456789", address: "789 CMT8, Q10", items: 100, status: "pending", time: "11:00-12:00", urgent: false },
  { id: 4, code: "DH004", customer: "Bệnh viện Quận 3", phone: "0934567890", address: "321 Trường Chinh, TB", items: 80, status: "done", time: "8:00-9:00", urgent: false },
]

const statusConfig = {
  pending: { label: "Chờ giao", color: "bg-warning/10 text-warning", icon: Circle },
  shipping: { label: "Đang giao", color: "bg-primary/10 text-primary", icon: Truck },
  done: { label: "Đã giao", color: "bg-success/10 text-success", icon: CheckCircle2 },
}

export default function DeliveryPage() {
  const [tasks, setTasks] = useState(initialTasks)
  const [filter, setFilter] = useState<Status | "all">("all")

  const updateStatus = (id: number, status: Status) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, status } : t)))
  }

  const filtered = filter === "all" ? tasks : tasks.filter((t) => t.status === filter)

  const stats = {
    pending: tasks.filter((t) => t.status === "pending").length,
    shipping: tasks.filter((t) => t.status === "shipping").length,
    done: tasks.filter((t) => t.status === "done").length,
  }

  return (
    <DashboardLayout>
      <div className="mb-4">
        <h1 className="text-xl font-bold">Giao hàng</h1>
        <p className="text-sm text-muted-foreground">Danh sách đơn cần giao hôm nay</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-warning">{stats.pending}</p>
            <p className="text-xs text-muted-foreground">Chờ giao</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-primary">{stats.shipping}</p>
            <p className="text-xs text-muted-foreground">Đang giao</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-success">{stats.done}</p>
            <p className="text-xs text-muted-foreground">Đã giao</p>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        {(["all", "pending", "shipping", "done"] as const).map((s) => (
          <Button
            key={s}
            variant={filter === s ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter(s)}
            className="h-9 shrink-0"
          >
            {s === "all" ? "Tất cả" : statusConfig[s].label}
          </Button>
        ))}
      </div>

      {/* Tasks */}
      <div className="space-y-3">
        {filtered.map((task) => {
          const config = statusConfig[task.status]
          const Icon = config.icon
          return (
            <Card key={task.id} className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-sm">{task.code}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${config.color}`}>
                        <Icon className="h-3 w-3 inline mr-1" />{config.label}
                      </span>
                      {task.urgent && <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/10 text-destructive">Gấp</span>}
                    </div>
                    <p className="font-medium">{task.customer}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{task.time}</span>
                </div>

                <div className="space-y-1 mb-3 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 shrink-0" />
                    <span className="truncate">{task.address}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span>{task.items} sản phẩm</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  {task.status === "pending" && (
                    <Button onClick={() => updateStatus(task.id, "shipping")} className="flex-1 h-11">
                      <Truck className="h-4 w-4 mr-2" />Bắt đầu giao
                    </Button>
                  )}
                  {task.status === "shipping" && (
                    <Button onClick={() => updateStatus(task.id, "done")} className="flex-1 h-11 bg-success hover:bg-success/90">
                      <CheckCircle2 className="h-4 w-4 mr-2" />Đã giao xong
                    </Button>
                  )}
                  <Button variant="outline" size="icon" className="h-11 w-11 shrink-0">
                    <Navigation className="h-4 w-4" />
                  </Button>
                  <a href={`tel:${task.phone}`}>
                    <Button variant="outline" size="icon" className="h-11 w-11">
                      <Phone className="h-4 w-4" />
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </DashboardLayout>
  )
}
