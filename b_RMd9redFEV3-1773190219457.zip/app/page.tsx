"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  Mic, 
  ScanBarcode, 
  Camera, 
  Package, 
  PackagePlus, 
  PackageMinus, 
  AlertTriangle,
  Clock,
  Truck,
  ChevronRight,
  Bell
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

// Mock user role - trong thực tế lấy từ auth
const userRole: "kho" | "giaovan" | "quanly" = "kho"

const roleAlerts = {
  kho: [
    { id: 1, type: "danger", title: "Mì Hảo Hảo - HSD còn 5 ngày", time: "2 phút trước" },
    { id: 2, type: "warning", title: "Nước suối Lavie - Tồn kho thấp", time: "15 phút trước" },
    { id: 3, type: "danger", title: "Dầu ăn Simply - HSD còn 3 ngày", time: "1 giờ trước" },
  ],
  giaovan: [
    { id: 1, type: "danger", title: "DH002 - Quá hạn giao 2 tiếng", time: "Ngay bây giờ" },
    { id: 2, type: "warning", title: "DH005 - Giao trong 30 phút", time: "5 phút trước" },
    { id: 3, type: "info", title: "3 đơn mới chờ nhận", time: "10 phút trước" },
  ],
  quanly: [
    { id: 1, type: "danger", title: "18 sản phẩm sắp hết hạn", time: "Hôm nay" },
    { id: 2, type: "warning", title: "5 đơn giao trễ hạn", time: "Hôm nay" },
    { id: 3, type: "info", title: "Doanh thu +12% so với hôm qua", time: "Cập nhật" },
  ],
}

const alertStyles = {
  danger: "bg-destructive/10 border-destructive/20 text-destructive",
  warning: "bg-warning/10 border-warning/20 text-warning-foreground",
  info: "bg-primary/10 border-primary/20 text-primary",
}

const stats = [
  { label: "Tồn kho", value: "8,456", icon: Package },
  { label: "Nhập", value: "156", icon: PackagePlus },
  { label: "Xuất", value: "89", icon: PackageMinus },
  { label: "Cảnh báo", value: "18", icon: AlertTriangle },
]

const recentOrders = [
  { id: "DH001", customer: "UBND Quận 1", total: "12.5tr", status: "pending" },
  { id: "DH002", customer: "Hội Chữ Thập Đỏ", total: "28tr", status: "shipping" },
  { id: "DH003", customer: "Trường THPT Lê Quý Đôn", total: "45tr", status: "done" },
]

const statusMap = {
  pending: { label: "Chờ", color: "bg-warning text-warning-foreground" },
  shipping: { label: "Giao", color: "bg-primary text-primary-foreground" },
  done: { label: "Xong", color: "bg-success text-success-foreground" },
}

export default function DashboardPage() {
  const [isListening, setIsListening] = useState(false)
  const alerts = roleAlerts[userRole]

  const handleVoice = () => {
    setIsListening(!isListening)
    // TODO: Integrate Web Speech API
  }

  const handleScan = () => {
    // TODO: Open camera for barcode scanning
    alert("Mở camera scan mã vạch")
  }

  const handleCamera = () => {
    // TODO: Open camera for photo capture
    alert("Mở camera chụp hình")
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-4 max-w-7xl mx-auto">
        {/* Header với Alert Button */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">Xin chào, Nguyễn Văn A</h1>
            <p className="text-xs text-muted-foreground">Thủ kho - FMCG Bán sỉ</p>
          </div>
          <Button variant="outline" size="icon" className="relative h-10 w-10" asChild>
            <Link href="/canh-bao">
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">
                {alerts.length}
              </span>
            </Link>
          </Button>
        </div>

        {/* Quick Actions - 3 Button lớn */}
        <Card className="border-0 shadow-sm bg-gradient-to-r from-primary/5 to-primary/10">
          <CardContent className="p-3">
            <div className="grid grid-cols-3 gap-2">
              <Button
                onClick={handleVoice}
                variant={isListening ? "default" : "secondary"}
                className={`h-16 flex-col gap-1 ${isListening ? "animate-pulse" : ""}`}
              >
                <Mic className="h-6 w-6" />
                <span className="text-xs font-medium">Giọng nói</span>
              </Button>
              <Button
                onClick={handleScan}
                variant="secondary"
                className="h-16 flex-col gap-1"
              >
                <ScanBarcode className="h-6 w-6" />
                <span className="text-xs font-medium">Scan mã</span>
              </Button>
              <Button
                onClick={handleCamera}
                variant="secondary"
                className="h-16 flex-col gap-1"
              >
                <Camera className="h-6 w-6" />
                <span className="text-xs font-medium">Chụp hình</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Row - Compact */}
        <div className="grid grid-cols-4 gap-2">
          {stats.map((stat) => (
            <Card key={stat.label} className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <stat.icon className="h-4 w-4 mx-auto mb-1 text-muted-foreground" />
                <p className="text-lg font-bold leading-none">{stat.value}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid gap-4 lg:grid-cols-2">
          {/* Cảnh báo theo Role */}
          <Card className="border-0 shadow-sm">
            <CardContent className="p-3">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-sm flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  Cảnh báo {userRole === "kho" ? "Kho" : userRole === "giaovan" ? "Giao vận" : "Quản lý"}
                </h2>
                <Link href="/canh-bao" className="text-xs text-primary flex items-center">
                  Xem tất cả <ChevronRight className="h-3 w-3" />
                </Link>
              </div>
              <div className="space-y-2">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`flex items-start gap-3 p-2.5 rounded-lg border ${alertStyles[alert.type as keyof typeof alertStyles]}`}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{alert.title}</p>
                      <p className="text-[10px] opacity-70 flex items-center gap-1 mt-0.5">
                        <Clock className="h-3 w-3" />
                        {alert.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Đơn hàng gần đây - Compact */}
          <Card className="border-0 shadow-sm">
            <CardContent className="p-3">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-sm flex items-center gap-2">
                  <Truck className="h-4 w-4 text-primary" />
                  Đơn hàng hôm nay
                </h2>
                <Link href="/xuat-kho" className="text-xs text-primary flex items-center">
                  Xem tất cả <ChevronRight className="h-3 w-3" />
                </Link>
              </div>
              <div className="space-y-2">
                {recentOrders.map((order) => {
                  const status = statusMap[order.status as keyof typeof statusMap]
                  return (
                    <div key={order.id} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/50">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{order.customer}</p>
                        <p className="text-[10px] text-muted-foreground">{order.id}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">{order.total}</span>
                        <Badge className={`text-[10px] px-1.5 py-0 ${status.color}`}>
                          {status.label}
                        </Badge>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" className="h-12 justify-start gap-3" asChild>
            <Link href="/nhap-kho">
              <PackagePlus className="h-5 w-5 text-success" />
              <span className="font-medium">Nhập kho mới</span>
            </Link>
          </Button>
          <Button variant="outline" className="h-12 justify-start gap-3" asChild>
            <Link href="/xuat-kho">
              <PackageMinus className="h-5 w-5 text-chart-3" />
              <span className="font-medium">Tạo đơn xuất</span>
            </Link>
          </Button>
        </div>
      </div>
    </DashboardLayout>
  )
}
