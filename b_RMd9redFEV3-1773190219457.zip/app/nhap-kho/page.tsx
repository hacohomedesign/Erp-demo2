"use client"

import { useState, useRef } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useVoiceInput } from "@/hooks/use-voice-input"
import { Mic, MicOff, Camera, QrCode, PackagePlus, Loader2, X } from "lucide-react"

interface StockItem {
  id: number
  name: string
  sku: string
  quantity: number
  unit: string
  addedAt: string
}

export default function StockInPage() {
  const { isListening, transcript, startListening, stopListening, resetTranscript, isSupported } = useVoiceInput()
  const [productName, setProductName] = useState("")
  const [sku, setSku] = useState("")
  const [quantity, setQuantity] = useState("")
  const [unit, setUnit] = useState("thùng")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [showScanner, setShowScanner] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [recentItems, setRecentItems] = useState<StockItem[]>([
    { id: 1, name: "Mì Hảo Hảo tôm chua cay", sku: "HH-TCH-30", quantity: 50, unit: "thùng", addedAt: "10:30" },
    { id: 2, name: "Nước suối Lavie 500ml", sku: "LV-500-24", quantity: 100, unit: "thùng", addedAt: "09:15" },
  ])

  // Parse voice command - simplified for FMCG
  const parseVoiceCommand = () => {
    if (!transcript) return
    const text = transcript.toLowerCase()
    
    // Extract quantity
    const qtyMatch = text.match(/(\d+)\s*(thùng|hộp|chai|lon|gói|kg|túi)?/i)
    if (qtyMatch) {
      setQuantity(qtyMatch[1])
      if (qtyMatch[2]) setUnit(qtyMatch[2])
    }

    // Extract product name (after quantity)
    const nameMatch = text.match(/\d+\s*(?:thùng|hộp|chai|lon|gói|kg|túi)?\s+(.+)/i)
    if (nameMatch) {
      setProductName(nameMatch[1].trim())
    }
  }

  const handleSubmit = async () => {
    if (!productName || !quantity) return
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 800))

    const newItem: StockItem = {
      id: Date.now(),
      name: productName,
      sku: sku || `SKU-${Date.now().toString().slice(-6)}`,
      quantity: parseInt(quantity),
      unit,
      addedAt: new Date().toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" }),
    }

    setRecentItems([newItem, ...recentItems])
    resetForm()
    setIsSubmitting(false)
  }

  const resetForm = () => {
    setProductName("")
    setSku("")
    setQuantity("")
    setUnit("thùng")
    resetTranscript()
  }

  const startCamera = async () => {
    setShowCamera(true)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
    } catch {
      alert("Không thể truy cập camera")
      setShowCamera(false)
    }
  }

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      stream.getTracks().forEach(track => track.stop())
    }
    setShowCamera(false)
  }

  const captureImage = () => {
    // In production: send to OCR API to extract product info
    alert("Đã chụp - Tính năng OCR sẽ tự động điền thông tin sản phẩm")
    stopCamera()
  }

  const startScanner = () => {
    setShowScanner(true)
    // In production: use barcode scanner library
    setTimeout(() => {
      setSku("HH-TCH-30")
      setProductName("Mì Hảo Hảo tôm chua cay")
      setShowScanner(false)
    }, 2000)
  }

  return (
    <DashboardLayout>
      <div className="mb-4">
        <h1 className="text-xl font-bold">Nhập kho</h1>
        <p className="text-sm text-muted-foreground">Nhập hàng FMCG bằng giọng nói, scan hoặc chụp hình</p>
      </div>

      {/* Quick Action Buttons - Always visible */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <Button
          onClick={isListening ? stopListening : startListening}
          disabled={!isSupported}
          className={`h-20 flex-col gap-2 ${isListening ? "bg-destructive hover:bg-destructive/90" : ""}`}
        >
          {isListening ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          <span className="text-xs">{isListening ? "Dừng" : "Giọng nói"}</span>
        </Button>
        <Button onClick={showScanner ? () => setShowScanner(false) : startScanner} variant={showScanner ? "destructive" : "default"} className="h-20 flex-col gap-2">
          <QrCode className="h-6 w-6" />
          <span className="text-xs">{showScanner ? "Dừng scan" : "Scan mã"}</span>
        </Button>
        <Button onClick={showCamera ? stopCamera : startCamera} variant={showCamera ? "destructive" : "default"} className="h-20 flex-col gap-2">
          <Camera className="h-6 w-6" />
          <span className="text-xs">{showCamera ? "Đóng" : "Chụp hình"}</span>
        </Button>
      </div>

      {/* Voice Transcript */}
      {transcript && (
        <Card className="border-0 shadow-sm mb-4">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Đã nhận:</span>
              <Button variant="ghost" size="sm" onClick={resetTranscript} className="h-8 px-2">
                <X className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm mb-3">{transcript}</p>
            <Button onClick={parseVoiceCommand} size="sm" className="w-full h-10">Áp dụng</Button>
          </CardContent>
        </Card>
      )}

      {/* Scanner */}
      {showScanner && (
        <Card className="border-0 shadow-sm mb-4">
          <CardContent className="p-4">
            <div className="h-48 bg-muted rounded-lg flex items-center justify-center">
              <div className="text-center">
                <QrCode className="h-12 w-12 mx-auto mb-2 text-muted-foreground animate-pulse" />
                <p className="text-sm text-muted-foreground">Đang quét mã vạch...</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Camera */}
      {showCamera && (
        <Card className="border-0 shadow-sm mb-4">
          <CardContent className="p-4">
            <video ref={videoRef} autoPlay playsInline className="w-full h-48 object-cover rounded-lg bg-muted" />
            <Button onClick={captureImage} className="w-full mt-3 h-12">
              <Camera className="h-5 w-5 mr-2" />
              Chụp
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Form */}
      <Card className="border-0 shadow-sm mb-4">
        <CardContent className="p-4 space-y-3">
          <Input
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            placeholder="Tên sản phẩm"
            className="h-12"
          />
          <Input
            value={sku}
            onChange={(e) => setSku(e.target.value)}
            placeholder="Mã SKU (tự tạo nếu trống)"
            className="h-12"
          />
          <div className="flex gap-3">
            <Input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder="Số lượng"
              className="h-12 flex-1"
            />
            <select
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="h-12 px-3 rounded-lg border bg-background text-sm"
            >
              <option value="thùng">Thùng</option>
              <option value="hộp">Hộp</option>
              <option value="chai">Chai</option>
              <option value="lon">Lon</option>
              <option value="gói">Gói</option>
              <option value="kg">Kg</option>
            </select>
          </div>
          <Button onClick={handleSubmit} disabled={!productName || !quantity || isSubmitting} className="w-full h-12">
            {isSubmitting ? <Loader2 className="h-5 w-5 animate-spin" /> : <><PackagePlus className="h-5 w-5 mr-2" />Nhập kho</>}
          </Button>
        </CardContent>
      </Card>

      {/* Recent */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <h2 className="font-semibold mb-3 text-sm">Vừa nhập</h2>
          <div className="space-y-2">
            {recentItems.slice(0, 5).map((item) => (
              <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-sm truncate">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{item.sku}</p>
                </div>
                <div className="text-right">
                  <span className="text-sm font-semibold text-success">+{item.quantity} {item.unit}</span>
                  <p className="text-xs text-muted-foreground">{item.addedAt}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
