"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Clock, Package, AlertCircle, X, Bell } from "lucide-react"

type AlertType = "expired" | "expiring" | "low_stock"

interface Alert {
  id: number
  type: AlertType
  product: string
  sku: string
  quantity: number
  expiryDate: string
  daysLeft: number
  dismissed: boolean
}

const initialAlerts: Alert[] = [
  { id: 1, type: "expired", product: "Sữa tươi Vinamilk 1L", sku: "VNM-1L-12", quantity: 30, expiryDate: "05/03/2026", daysLeft: -5, dismissed: false },
  { id: 2, type: "expiring", product: "Bánh Oreo 150g", sku: "OR-150-24", quantity: 60, expiryDate: "15/03/2026", daysLeft: 5, dismissed: false },
  { id: 3, type: "expiring", product: "Nước ngọt Coca 330ml", sku: "CC-330-24", quantity: 100, expiryDate: "20/03/2026", daysLeft: 10, dismissed: false },
  { id: 4, type: "low_stock", product: "Dầu ăn Neptune 1L", sku: "NP-1L-12", quantity: 5, expiryDate: "", daysLeft: 0, dismissed: false },
  { id: 5, type: "expiring", product: "Mì Hảo Hảo", sku: "HH-TCH-30", quantity: 200, expiryDate: "25/03/2026", daysLeft: 15, dismissed: false },
  { id: 6, type: "low_stock", product: "Nước mắm Chinsu", sku: "CS-500-24", quantity: 3, expiryDate: "", daysLeft: 0, dismissed: false },
]

const typeConfig = {
  expired: { label: "Hết hạn", color: "border-destructive/30 bg-destructive/5", icon: AlertCircle, iconColor: "text-destructive" },
  expiring: { label: "Sắp hết hạn", color: "border-warning/30 bg-warning/5", icon: Clock, iconColor: "text-warning" },
  low_stock: { label: "Tồn thấp", color: "border-chart-3/30 bg-chart-3/5", icon: Package, iconColor: "text-chart-3" },
}

export default function AlertsPage() {
  const [alerts, setAlerts] = useState(initialAlerts)
  const [filter, setFilter] = useState<AlertType | "all">("all")

  const dismiss = (id: number) => setAlerts(alerts.map((a) => (a.id === id ? { ...a, dismissed: true } : a)))
  const restore = (id: number) => setAlerts(alerts.map((a) => (a.id === id ? { ...a, dismissed: false } : a)))

  const active = alerts.filter((a) => !a.dismissed)
  const dismissed = alerts.filter((a) => a.dismissed)
  const filtered = filter === "all" ? active : active.filter((a) => a.type === filter)

  const stats = {
    expired: active.filter((a) => a.type === "expired").length,
    expiring: active.filter((a) => a.type === "expiring").length,
    lowStock: active.filter((a) => a.type === "low_stock").length,
  }

  return (
    <DashboardLayout>
      <div className="mb-4">
        <h1 className="text-xl font-bold">Cảnh báo</h1>
        <p className="text-sm text-muted-foreground">Hàng hết hạn và tồn kho thấp</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-destructive">{stats.expired}</p>
            <p className="text-xs text-muted-foreground">Hết hạn</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-warning">{stats.expiring}</p>
            <p className="text-xs text-muted-foreground">Sắp hết hạn</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-chart-3">{stats.lowStock}</p>
            <p className="text-xs text-muted-foreground">Tồn thấp</p>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        {(["all", "expired", "expiring", "low_stock"] as const).map((t) => (
          <Button
            key={t}
            variant={filter === t ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter(t)}
            className="h-9 shrink-0"
          >
            {t === "all" ? "Tất cả" : typeConfig[t].label}
          </Button>
        ))}
      </div>

      {/* Alerts */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-8 text-center">
              <AlertTriangle className="h-10 w-10 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Không có cảnh báo</p>
            </CardContent>
          </Card>
        ) : (
          filtered.map((alert) => {
            const config = typeConfig[alert.type]
            const Icon = config.icon
            return (
              <Card key={alert.id} className={`border shadow-sm ${config.color}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-card">
                      <Icon className={`h-5 w-5 ${config.iconColor}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm truncate">{alert.product}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{alert.sku} - SL: {alert.quantity}</p>
                      {alert.type !== "low_stock" && (
                        <p className="text-xs mt-1">
                          {alert.type === "expired" ? (
                            <span className="text-destructive">Hết hạn {Math.abs(alert.daysLeft)} ngày trước</span>
                          ) : (
                            <span>Còn {alert.daysLeft} ngày ({alert.expiryDate})</span>
                          )}
                        </p>
                      )}
                    </div>
                    <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => dismiss(alert.id)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })
        )}
      </div>

      {/* Dismissed */}
      {dismissed.length > 0 && (
        <Card className="border-0 shadow-sm mt-6">
          <CardContent className="p-4">
            <h2 className="font-semibold text-sm mb-3">Đã bỏ qua ({dismissed.length})</h2>
            <div className="space-y-2">
              {dismissed.map((alert) => (
                <div key={alert.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                  <span className="text-sm text-muted-foreground truncate">{alert.product}</span>
                  <Button variant="ghost" size="sm" onClick={() => restore(alert.id)} className="h-8 px-2">
                    <Bell className="h-4 w-4 mr-1" />Khôi phục
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </DashboardLayout>
  )
}
